import pyduinocli

arduino = pyduinocli.Arduino("./arduino-cli")
print(arduino.version())

pyduinocli compile ("C:\Users\lalit\OneDrive\Documentos\pycharm projects\RobotSemanaTec\main.py")
